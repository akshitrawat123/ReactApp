import "./App.css";
import TodoForm from "./Components/TodoForm";

function App() {
	return (
		<div className="container mt-5 p-5">
			<TodoForm />
		</div>
	);
}

export default App;
